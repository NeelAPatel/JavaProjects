import javafx.animation.Transition;

import javafx.beans.property.ObjectProperty;
import javafx.beans.property.ObjectPropertyBase;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

import javafx.scene.text.Text;

import javafx.util.Duration;

public class TypewriterTransition extends Transition
{
   public TypewriterTransition() 
   {
      this(DEFAULT_DURATION, null, null);
   }

   public TypewriterTransition(Duration duration) 
   {
      this(duration, null, null);
   }

   public TypewriterTransition(Duration duration, Text text, String string)
   {
      setDuration(duration);
      setText(text);
      setString(string);
      setCycleDuration(duration);
   }

   private ObjectProperty<Duration> duration;
   private static final Duration DEFAULT_DURATION = Duration.millis(400);

   public final void setDuration(Duration value) 
   {
      if ((duration != null) || (!DEFAULT_DURATION.equals(value)))
         durationProperty().set(value);
   }

   public final Duration getDuration() 
   {
      return (duration == null) ? DEFAULT_DURATION : duration.get();
   }

   public final ObjectProperty<Duration> durationProperty() 
   {
      if (duration == null)
      {
         duration = new ObjectPropertyBase<Duration>(DEFAULT_DURATION) 
                        {
                           @Override
                           public void invalidated() 
                           {
                              try 
                              {
                                 setCycleDuration(getDuration());
                              } 
                              catch (IllegalArgumentException iae) 
                              {
                                 if (isBound())
                                    unbind();
                                 set(getCycleDuration());
                                 throw iae;
                              }
                           }

                           @Override
                           public Object getBean() 
                           {
                               return TypewriterTransition.this;
                           }

                           @Override
                           public String getName() 
                           {
                              return "duration";
                           }
                        };
      }
      return duration;
   }

   private StringProperty string;
   private static final String DEFAULT_STRING = null;

   public final void setString(String value) 
   {
      if ((string != null) || (value != null /* DEFAULT_STRING */))
         stringProperty().set(value);
   }

   public final String getString() 
   {
      return (string == null) ? DEFAULT_STRING : string.get();
   }

   public final StringProperty stringProperty() 
   {
      if (string == null)
         string = new SimpleStringProperty(this, "string", DEFAULT_STRING);
      return string;
   }

   private ObjectProperty<Text> text;
   private static final Text DEFAULT_TEXT = null;

   public final void setText(Text value) 
   {
      if ((text != null) || (value != null /* DEFAULT_TEXT */))
         textProperty().set(value);
   }

   public final Text getText() 
   {
      return (text == null) ? DEFAULT_TEXT : text.get();
   }

   public final ObjectProperty<Text> textProperty() 
   {
      if (text == null)
         text = new SimpleObjectProperty<Text>(this, "text", DEFAULT_TEXT);
      return text;
   }

   @Override
   protected void interpolate(double frac) 
   {
      final int length = string.get().length();
      final int n = Math.round(length * (float) frac);
      getText().setText(string.get().substring(0, n));
   }
}