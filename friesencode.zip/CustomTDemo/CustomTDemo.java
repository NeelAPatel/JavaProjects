import javafx.animation.Animation;
import javafx.animation.Transition;

import javafx.application.Application;

import javafx.beans.value.ChangeListener;

import javafx.geometry.VPos;

import javafx.scene.Group;
import javafx.scene.Scene;

import javafx.scene.text.Font;
import javafx.scene.text.Text;

import javafx.stage.Stage;

import javafx.util.Duration;

public class CustomTDemo extends Application
{
   final static int SCENE_WIDTH = 300;
   final static int SCENE_HEIGHT = 200;

   @Override
   public void start(Stage primaryStage)
   {
      final Text text = new Text(0, 0, "");
      text.setFont(new Font("Arial Bold", 24));
      text.setTextOrigin(VPos.TOP);

      TypewriterTransition tt = new TypewriterTransition();
      tt.setDuration(new Duration(2000));
      tt.setString("Lorem ipsum");
      tt.setText(text);
      tt.setOnFinished(e -> { text.setText(""); tt.play(); });

      Group root = new Group();
      root.getChildren().add(text);
      Scene scene = new Scene(root, SCENE_WIDTH, SCENE_HEIGHT);

      text.layoutBoundsProperty().addListener((observable, oldValue, newValue) -> 
                                              {
                                                 text.setX((scene.getWidth() - 
                                                           newValue.getWidth()) 
                                                           / 2);
                                                 text.setY((scene.getHeight() - 
                                                           newValue.getHeight()) 
                                                           / 2);
                                              });

      primaryStage.setTitle("CustomTransition Demo");
      primaryStage.setScene(scene);
      primaryStage.show();

      tt.play();
   }
}