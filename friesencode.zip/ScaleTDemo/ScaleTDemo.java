import javafx.application.Application;

import javafx.scene.Group;
import javafx.scene.Scene;

import javafx.scene.paint.Color;
import javafx.scene.paint.CycleMethod;
import javafx.scene.paint.LinearGradient;
import javafx.scene.paint.Stop;

import javafx.stage.Stage;

import javafx.util.Duration;

public class ScaleTDemo extends Application
{
   final static int NUMIMAGES = 5;

   @Override
   public void start(Stage primaryStage)
   {
      Stop[] stops = new Stop[] 
      { 
         new Stop(0.0, Color.YELLOW), 
         new Stop(0.5, Color.ORANGE),
         new Stop(1.0, Color.PINK)
      };
      LinearGradient lg = new LinearGradient(0, 0, 1, 1, true,
                                             CycleMethod.NO_CYCLE,
                                             stops);
      Group root = new Group();
      Scene scene = new Scene(root, 750, 400, lg);

      Thumbnail[] thumbnails = new Thumbnail[NUMIMAGES];
      for (int i = 0; i < NUMIMAGES; i++)
      {
         thumbnails[i] = new Thumbnail("res/photo" + (i + 1) + ".jpg");
         thumbnails[i].setWidth(100);
         thumbnails[i].setHeight(100);
         thumbnails[i].setTranslateX((scene.getWidth() + 10 -
                                     NUMIMAGES * thumbnails[i].getWidth() -
                                     10 * (NUMIMAGES - 1)) / 2 +
                                     i * (thumbnails[i].getWidth() + 10));
         thumbnails[i].setTranslateY((scene.getHeight() - 
                                     thumbnails[i].getHeight()) / 2);
         root.getChildren().add(thumbnails[i]);
      }

      scene.widthProperty()
      .addListener((observable, oldValue, newValue) ->
                   {
                      for (int i = 0; i < NUMIMAGES; i++)
                      {
                         double w = thumbnails[i].getLayoutBounds().getWidth();
                         thumbnails[i].setTranslateX((newValue.doubleValue() + 
                                                     10 - NUMIMAGES * w -
                                                     10 * (NUMIMAGES - 1)) / 2 +
                                                     i * (w + 10));
                      }
                   });
      scene.heightProperty()
      .addListener((observable, oldValue, newValue) ->
                   {
                      for (int i = 0; i < NUMIMAGES; i++)
                      {
                         double h = thumbnails[i].getLayoutBounds().getHeight();
                         thumbnails[i].setTranslateY((newValue.doubleValue() - 
                                                     h) / 2);
                      }
                   });

      primaryStage.setTitle("ScaleTransition Demo");
      primaryStage.setScene(scene);
      primaryStage.show();
   }
}